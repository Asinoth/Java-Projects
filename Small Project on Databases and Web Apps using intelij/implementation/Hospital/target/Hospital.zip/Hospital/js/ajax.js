var info;
var wei,hei,age,gen;
function createTableFromJSON(data) {
    var html = "<table><tr><th>Category</th><th>Value</th></tr>";
    for (const x in data) {
        if(x!="user_id"){
            var category = x;
            var value = data[x];
            html += "<tr><td>" + category + "</td><td>" + value + "</td></tr>";
        }
    }
    html += "</table>";
    return html;

}

function createDataFromJSON(data) {
    var html = "<div class='row'><h2 class='w-50'>Your Information</h2><button class=\"btn btn-primary ml-3 w-50\" id=\"change-but\" type=\"button\" onclick=change(";
    html += ")>Edit</button></div>";
    html += "<div class='row' id='info-t'><table id='t-inf' class=\"table table-success table-striped\">";
    var weight=0,height=0;
    for (const x in data) {
        if(x!="user_id"){
            var category = x;
            var value = data[x];

            html += "<tr><td>" + category + "</td><td>" + value + "</td></tr>";

        }
        if(x == "weight"){
            wei = data[x];
            weight = data[x];
        }
        if(x == "height"){
            hei = data[x];
            height = data[x];
        }
        if(x == "birthdate"){
            age = data[x];
            let year = age.substr(0,4);
            age = 2021 - parseInt(year);
        }
        if(x == "gender"){
            gen = data[x].toLowerCase();
        }
    }
    html += "</table></div>";
    if(weight!=0 && height!=0){
        bmi();
    }
    if(gen!="unknown"){
        ideal_weight();
    }

    return html;

}



function getUser(username,password) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            info = xhr.responseText;

        } else if (xhr.status !== 200) {
            console.log("user not exists!");
        }
    };
    var data = "username="+username+"&password="+password;
    xhr.open('GET', 'GetUser?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
}

function checkUsername() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("name_exists").removeAttribute("hidden");
        }else if (xhr.status !== 200) {
            document.getElementById("name_exists").setAttribute("hidden","true");
        }
    }

    var data = "username="+document.getElementById("username").value;
    xhr.open('GET', 'GetUsername?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("hello");
}

function checkEmail() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("email_exists").removeAttribute("hidden");
        }else if (xhr.status !== 200) {
            document.getElementById("email_exists").setAttribute("hidden","true");
        }
    }

    var data = "email="+document.getElementById("email").value;
    xhr.open('GET', 'getEmail?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("hello");
}

function checkAmka(){
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("amka_exists").removeAttribute("hidden");
        }else if (xhr.status !== 200) {
            document.getElementById("amka_exists").setAttribute("hidden","true");
        }
    }

    var data = "amka="+document.getElementById("amka").value;
    xhr.open('GET', 'getAmka?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("hello");
}


function addUser(){
    var type = document.getElementById("type");
    var value = type.options[type.selectedIndex].text;

    if(value == "Simple User"){
        let xhr = new XMLHttpRequest();
        xhr.onload = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log("success!!");
                const resp = JSON.parse(xhr.responseText);
                $("#ajaxContent").html("<h1>Successful Registration. Now please log in!</h1><br> Your Data");
                ;
                $("#ajaxContent").append((createTableFromJSON(resp)));
                console.log(resp);
            }
        }
        let data = $('#loginForm').serialize();
        xhr.open('GET', 'addUser?'+data);
        xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
        xhr.send();
        console.log("addUser");
    }else{
        let xhr = new XMLHttpRequest();
        xhr.onload = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log("success!!");
                const resp = JSON.parse(xhr.responseText);
                $("#ajaxContent").html("<h1>Successful Registration, but you have to be verified from the administrator!</h1><br> Your Data");
                ;
                $("#ajaxContent").append((createTableFromJSON(resp)));
                console.log(resp);
            }
        }
        let data = $('#loginForm').serialize();
        xhr.open('GET', 'addDoctor?'+data);
        xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
        xhr.send();
        console.log("addDoctor");
    }


}

function showRegistrationForm(){
    $("#ajaxContent").load("register.html");
}

function showLoginForm(){
    $("#ajaxContent").load("login.html");
}

function login(){
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            $("#ajaxContent").load("logged.html",function (){
                const resp = JSON.parse(xhr.responseText);
                console.log(resp);
                info = JSON.parse(xhr.responseText);
                console.log("info: "+info);
                for (const x in resp) {
                    if(x == "username"){
                        document.getElementById("title").innerText = "Welcome "+resp[x];
                    }
                }
                $("#content").append((createDataFromJSON(resp)));
            });
        }else if (xhr.status !== 200) {
            document.getElementById("wc").removeAttribute("hidden");
        }
    }
    let data = $('#loginForm1').serialize();
    xhr.open('POST', 'Login?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("login");
}

function isLogged() {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            $("#ajaxContent").load("logged.html",function (){
                const resp = JSON.parse(xhr.responseText);
                for (const x in resp) {
                    if(x == "username"){
                        document.getElementById("title").innerText = "Welcome again "+resp[x];
                    }
                }
                console.log(resp);
                info = resp;
                $("#content").append((createDataFromJSON(resp)));
            });
        }else{
            $("#ajaxContent").load("buttons.html");
        }
    }
    xhr.open('POST', 'Login?'+info);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
}

$(document).ready(function ()
{
    isLogged();
});

function logout(){
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            $("#ajaxContent").load("buttons.html");
        }
    }
    xhr.open('POST', 'Logout?');
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("logout");
}

function change(){
    var data = info;
    $("#t-inf").remove();
    document.getElementById("change-but").innerText = "Save";
    document.getElementById("change-but").removeAttribute("onclick");
    document.getElementById("change-but").setAttribute("onclick","save()");
    var html = "<form id=\"loginForm\">";
    console.log("info: " + info);
    console.log("data: "+ data);
    for (const x in data) {
        console.log(x);
        if(x!= "username" && x!="amka" && x!="gender" && x!= "country" && x != "blooddonor" && x!="user_id"){
            html += "<div class=\"mb-3\">";
            html += "<label for='" + x +"' class=\"form-label\">" + x + "</label>";
            if(x=="email"){
                html += "<input type='email' class='form-control' id='" + x + "' name='" + x + "' value='" + data[x] + "' required onchange='checkEmail();return false;'>"
                html += "<div id='" + x + "Help' className='form-text'>at least 8 characters (only latin letters)</div>";
                html += "<p id=\"email_exists\" hidden>This email already taken!</p>";
            }else if(x == "password"){
                html += "<div class=\"input-group\">\n" +
                    "            <input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" aria-describedby=\"passwordHelp\"\n value='" + data[x] +
                    "                  ' pattern=\"(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,15}\" required onchange=\"checkIfStrong()\">\n" +
                    "            <button class=\"btn btn-primary\" id=\"pass-but\" type=\"button\" onclick=show_pass()>Show Password</button>\n" +
                    "        </div>\n" +
                    "        <p id=\"pass_power\"></p>\n" +
                    "        <div id=\"passwordHelp1\" class=\"form-text\">8 to 15 characters It should contain at least one character, one\n" +
                    "            number and one symbol (e.g., ‘#’, ‘$’)</div>";
            }else if(x == "firstname"){
                html += "<input type=\"text\" class=\"form-control\" id=\"firstname\" name=\"firstname\" aria-describedby=\"nameHelp\" required pattern=\"[A-Za-z]{3,30}\" value='" + data[x] + "'>" +
                    "        <div id=\"nameHelp\" class=\"form-text\">3-30 characters</div>";
            }else if(x == "lastname"){
                html += "<input type=\"text\" class=\"form-control\" id=\"lastname\" name=\"lastname\" aria-describedby=\"surnameHelp\" required pattern=\"[A-Za-z]{3,30}\" value='" + data[x] + "'>\n" +
                    "        <div id=\"surnameHelp\" class=\"form-text\">3-30 characters</div>";
            }else if(x == "birthdate") {
                html += "<input type=\"date\" id=\"birthdate\" name=\"birthdate\"\n" +
                    "               value='"+ data[x] + "' " +
                    "               min=\"1920-01-01\" max=\"2005-12-31\" required >";
            }else if(x == "city"){
                html += "<input type=\"text\" class=\"form-control\" id=\"city\" name=\"city\" aria-describedby=\"townHelp\" required pattern=\"[A-Za-z]{3,50}\" value='" + data[x] + "'>\n" +
                    "        <div id=\"townHelp\" class=\"form-text\">3-50 characters</div>";
            }else if(x == "address"){
                html += "<input type=\"text\" class=\"form-control\" id=\"address\" name=\"address\" aria-describedby=\"addressHelp\" required pattern=\"[A-Za-z 0-9]{5,50}\" onchange=\"check_address()\" value='" + data[x] + "'>\n" +
                    "        <div id=\"addressHelp\" class=\"form-text\">5-50 characters</div>\n" +
                    "        <p hidden id=\"address_p\">This address is not available!</p>\n" +
                    "        <button class=\"btn btn-primary mt-3 mb-3\" id=\"auto_comp\" onclick=\"complete()\">Auto-Complete Address</button>\n" +
                    "        <button class=\"btn btn-primary\" id=\"map_btn\" onclick=\"create_map()\" hidden>See Address in Map</button>\n" +
                    "        <div id=\"Map\" style=\"height:200px; width:300px\" hidden></div>";
            }else if(x == "lat"){
                html += "<input type=\"text\" class=\"form-control\" id=\"lat\" name=\"lat\" value='" + data[x] + "'>";
            }else if(x == "lon"){
                html += "<input type=\"text\" class=\"form-control\" id=\"lon\" name=\"lon\" value='" + data[x] + "'>";
            }else if(x == "telephone"){
                html += "<input type=\"text\" class=\"form-control\" id=\"telephone\" name=\"telephone\" required pattern=\"[0-9]{1,14}\" value='" + data[x] + "'>";
            }else if(x == "height"){
                html += "<input type=\"text\" class=\"form-control\" id=\"height\" name=\"height\" pattern=\"(1[0-9][0-9]|2[0-4][0-9]|250)\" value='" + data[x] + "'>";
            }else if(x == "weight"){
                html += "<input type=\"text\" class=\"form-control\" id=\"weight\" name=\"weight\" pattern=\"([1-2][0-9][0-9]|300|[2-9][0-9])\" value='" + data[x] + "'>";
            }else if(x == "bloodtype"){
                html += "<select id=\"bloodtype\" name=\"bloodtype\" class=\"form-select\">\n" +
                    "            <option value=\"A-\" selected>A-</option>\n" +
                    "            <option value=\"A+\" >A+</option>\n" +
                    "            <option value=\"B-\">B-</option>\n" +
                    "            <option value=\"B+\">B+</option>\n" +
                    "            <option value=\"AB-\">AB-</option>\n" +
                    "            <option value=\"AB+\">AB+</option>\n" +
                    "            <option value=\"0-\">0-</option>\n" +
                    "            <option value=\"0+\">0+</option>\n" +
                    "            <option value=\"unknown\">Unknown</option>\n" +
                    "        </select>";
            }
            html += "</div>";
        }else if(x == "gender" && data[x]=="Male"){
            html += "<p>Sex:</p>\n" +
                "    <div class=\"form-check black\">\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Female\" id=\"sexchoice1\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice1\">Female</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Male\" id=\"sexchoice2\" checked>\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice2\">Male</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"N/A\" id=\"sexchoice3\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice3\">N/A</label>\n" +
                "    </div>";
        }else if(x == "gender" && data[x]=="Female"){
            html += "<p>Sex:</p>\n" +
                "    <div class=\"form-check black\">\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Female\" id=\"sexchoice1\" checked>\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice1\">Female</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Male\" id=\"sexchoice2\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice2\">Male</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"N/A\" id=\"sexchoice3\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice3\">N/A</label>\n" +
                "    </div>";
        }else if(x == "gender"){
            html += "<p>Sex:</p>\n" +
                "    <div class=\"form-check black\">\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Female\" id=\"sexchoice1\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice1\">Female</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"Male\" id=\"sexchoice2\">\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice2\">Male</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"gender\" value=\"N/A\" id=\"sexchoice3\" checked>\n" +
                "        <label class=\"form-check-label\" for=\"sexchoice3\">N/A</label>\n" +
                "    </div>";
        }else if(x == "country"){
            html += "<div>\n" +
                "        <label for=\"country\" class=\"form-label\">Country</label>\n" +
                "        <select id=\"country\" name=\"country\" class=\"form-select\">\n" +
                "            <option value=\"AF\">Afghanistan</option>\n" +
                "            <option value=\"AX\">Åland Islands</option>\n" +
                "            <option value=\"AL\">Albania</option>\n" +
                "            <option value=\"DZ\">Algeria</option>\n" +
                "            <option value=\"AS\">American Samoa</option>\n" +
                "            <option value=\"AD\">Andorra</option>\n" +
                "            <option value=\"AO\">Angola</option>\n" +
                "            <option value=\"AI\">Anguilla</option>\n" +
                "            <option value=\"AQ\">Antarctica</option>\n" +
                "            <option value=\"AG\">Antigua and Barbuda</option>\n" +
                "            <option value=\"AR\">Argentina</option>\n" +
                "            <option value=\"AM\">Armenia</option>\n" +
                "            <option value=\"AW\">Aruba</option>\n" +
                "            <option value=\"AU\">Australia</option>\n" +
                "            <option value=\"AT\">Austria</option>\n" +
                "            <option value=\"AZ\">Azerbaijan</option>\n" +
                "            <option value=\"BS\">Bahamas</option>\n" +
                "            <option value=\"BH\">Bahrain</option>\n" +
                "            <option value=\"BD\">Bangladesh</option>\n" +
                "            <option value=\"BB\">Barbados</option>\n" +
                "            <option value=\"BY\">Belarus</option>\n" +
                "            <option value=\"BE\">Belgium</option>\n" +
                "            <option value=\"BZ\">Belize</option>\n" +
                "            <option value=\"BJ\">Benin</option>\n" +
                "            <option value=\"BM\">Bermuda</option>\n" +
                "            <option value=\"BT\">Bhutan</option>\n" +
                "            <option value=\"BO\">Bolivia, Plurinational State of</option>\n" +
                "            <option value=\"BQ\">Bonaire, Sint Eustatius and Saba</option>\n" +
                "            <option value=\"BA\">Bosnia and Herzegovina</option>\n" +
                "            <option value=\"BW\">Botswana</option>\n" +
                "            <option value=\"BV\">Bouvet Island</option>\n" +
                "            <option value=\"BR\">Brazil</option>\n" +
                "            <option value=\"IO\">British Indian Ocean Territory</option>\n" +
                "            <option value=\"BN\">Brunei Darussalam</option>\n" +
                "            <option value=\"BG\">Bulgaria</option>\n" +
                "            <option value=\"BF\">Burkina Faso</option>\n" +
                "            <option value=\"BI\">Burundi</option>\n" +
                "            <option value=\"KH\">Cambodia</option>\n" +
                "            <option value=\"CM\">Cameroon</option>\n" +
                "            <option value=\"CA\">Canada</option>\n" +
                "            <option value=\"CV\">Cape Verde</option>\n" +
                "            <option value=\"KY\">Cayman Islands</option>\n" +
                "            <option value=\"CF\">Central African Republic</option>\n" +
                "            <option value=\"TD\">Chad</option>\n" +
                "            <option value=\"CL\">Chile</option>\n" +
                "            <option value=\"CN\">China</option>\n" +
                "            <option value=\"CX\">Christmas Island</option>\n" +
                "            <option value=\"CC\">Cocos (Keeling) Islands</option>\n" +
                "            <option value=\"CO\">Colombia</option>\n" +
                "            <option value=\"KM\">Comoros</option>\n" +
                "            <option value=\"CG\">Congo</option>\n" +
                "            <option value=\"CD\">Congo, the Democratic Republic of the</option>\n" +
                "            <option value=\"CK\">Cook Islands</option>\n" +
                "            <option value=\"CR\">Costa Rica</option>\n" +
                "            <option value=\"CI\">Côte d'Ivoire</option>\n" +
                "            <option value=\"HR\">Croatia</option>\n" +
                "            <option value=\"CU\">Cuba</option>\n" +
                "            <option value=\"CW\">Curaçao</option>\n" +
                "            <option value=\"CY\">Cyprus</option>\n" +
                "            <option value=\"CZ\">Czech Republic</option>\n" +
                "            <option value=\"DK\">Denmark</option>\n" +
                "            <option value=\"DJ\">Djibouti</option>\n" +
                "            <option value=\"DM\">Dominica</option>\n" +
                "            <option value=\"DO\">Dominican Republic</option>\n" +
                "            <option value=\"EC\">Ecuador</option>\n" +
                "            <option value=\"EG\">Egypt</option>\n" +
                "            <option value=\"SV\">El Salvador</option>\n" +
                "            <option value=\"GQ\">Equatorial Guinea</option>\n" +
                "            <option value=\"ER\">Eritrea</option>\n" +
                "            <option value=\"EE\">Estonia</option>\n" +
                "            <option value=\"ET\">Ethiopia</option>\n" +
                "            <option value=\"FK\">Falkland Islands (Malvinas)</option>\n" +
                "            <option value=\"FO\">Faroe Islands</option>\n" +
                "            <option value=\"FJ\">Fiji</option>\n" +
                "            <option value=\"FI\">Finland</option>\n" +
                "            <option value=\"FR\">France</option>\n" +
                "            <option value=\"GF\">French Guiana</option>\n" +
                "            <option value=\"PF\">French Polynesia</option>\n" +
                "            <option value=\"TF\">French Southern Territories</option>\n" +
                "            <option value=\"GA\">Gabon</option>\n" +
                "            <option value=\"GM\">Gambia</option>\n" +
                "            <option value=\"GE\">Georgia</option>\n" +
                "            <option value=\"DE\">Germany</option>\n" +
                "            <option value=\"GH\">Ghana</option>\n" +
                "            <option value=\"GI\">Gibraltar</option>\n" +
                "            <option value=\"GR\" selected>Greece</option>\n" +
                "            <option value=\"GL\">Greenland</option>\n" +
                "            <option value=\"GD\">Grenada</option>\n" +
                "            <option value=\"GP\">Guadeloupe</option>\n" +
                "            <option value=\"GU\">Guam</option>\n" +
                "            <option value=\"GT\">Guatemala</option>\n" +
                "            <option value=\"GG\">Guernsey</option>\n" +
                "            <option value=\"GN\">Guinea</option>\n" +
                "            <option value=\"GW\">Guinea-Bissau</option>\n" +
                "            <option value=\"GY\">Guyana</option>\n" +
                "            <option value=\"HT\">Haiti</option>\n" +
                "            <option value=\"HM\">Heard Island and McDonald Islands</option>\n" +
                "            <option value=\"VA\">Holy See (Vatican City State)</option>\n" +
                "            <option value=\"HN\">Honduras</option>\n" +
                "            <option value=\"HK\">Hong Kong</option>\n" +
                "            <option value=\"HU\">Hungary</option>\n" +
                "            <option value=\"IS\">Iceland</option>\n" +
                "            <option value=\"IN\">India</option>\n" +
                "            <option value=\"ID\">Indonesia</option>\n" +
                "            <option value=\"IR\">Iran, Islamic Republic of</option>\n" +
                "            <option value=\"IQ\">Iraq</option>\n" +
                "            <option value=\"IE\">Ireland</option>\n" +
                "            <option value=\"IM\">Isle of Man</option>\n" +
                "            <option value=\"IL\">Israel</option>\n" +
                "            <option value=\"IT\">Italy</option>\n" +
                "            <option value=\"JM\">Jamaica</option>\n" +
                "            <option value=\"JP\">Japan</option>\n" +
                "            <option value=\"JE\">Jersey</option>\n" +
                "            <option value=\"JO\">Jordan</option>\n" +
                "            <option value=\"KZ\">Kazakhstan</option>\n" +
                "            <option value=\"KE\">Kenya</option>\n" +
                "            <option value=\"KI\">Kiribati</option>\n" +
                "            <option value=\"KP\">Korea, Democratic People's Republic of</option>\n" +
                "            <option value=\"KR\">Korea, Republic of</option>\n" +
                "            <option value=\"KW\">Kuwait</option>\n" +
                "            <option value=\"KG\">Kyrgyzstan</option>\n" +
                "            <option value=\"LA\">Lao People's Democratic Republic</option>\n" +
                "            <option value=\"LV\">Latvia</option>\n" +
                "            <option value=\"LB\">Lebanon</option>\n" +
                "            <option value=\"LS\">Lesotho</option>\n" +
                "            <option value=\"LR\">Liberia</option>\n" +
                "            <option value=\"LY\">Libya</option>\n" +
                "            <option value=\"LI\">Liechtenstein</option>\n" +
                "            <option value=\"LT\">Lithuania</option>\n" +
                "            <option value=\"LU\">Luxembourg</option>\n" +
                "            <option value=\"MO\">Macao</option>\n" +
                "            <option value=\"MK\">Macedonia, the former Yugoslav Republic of</option>\n" +
                "            <option value=\"MG\">Madagascar</option>\n" +
                "            <option value=\"MW\">Malawi</option>\n" +
                "            <option value=\"MY\">Malaysia</option>\n" +
                "            <option value=\"MV\">Maldives</option>\n" +
                "            <option value=\"ML\">Mali</option>\n" +
                "            <option value=\"MT\">Malta</option>\n" +
                "            <option value=\"MH\">Marshall Islands</option>\n" +
                "            <option value=\"MQ\">Martinique</option>\n" +
                "            <option value=\"MR\">Mauritania</option>\n" +
                "            <option value=\"MU\">Mauritius</option>\n" +
                "            <option value=\"YT\">Mayotte</option>\n" +
                "            <option value=\"MX\">Mexico</option>\n" +
                "            <option value=\"FM\">Micronesia, Federated States of</option>\n" +
                "            <option value=\"MD\">Moldova, Republic of</option>\n" +
                "            <option value=\"MC\">Monaco</option>\n" +
                "            <option value=\"MN\">Mongolia</option>\n" +
                "            <option value=\"ME\">Montenegro</option>\n" +
                "            <option value=\"MS\">Montserrat</option>\n" +
                "            <option value=\"MA\">Morocco</option>\n" +
                "            <option value=\"MZ\">Mozambique</option>\n" +
                "            <option value=\"MM\">Myanmar</option>\n" +
                "            <option value=\"NA\">Namibia</option>\n" +
                "            <option value=\"NR\">Nauru</option>\n" +
                "            <option value=\"NP\">Nepal</option>\n" +
                "            <option value=\"NL\">Netherlands</option>\n" +
                "            <option value=\"NC\">New Caledonia</option>\n" +
                "            <option value=\"NZ\">New Zealand</option>\n" +
                "            <option value=\"NI\">Nicaragua</option>\n" +
                "            <option value=\"NE\">Niger</option>\n" +
                "            <option value=\"NG\">Nigeria</option>\n" +
                "            <option value=\"NU\">Niue</option>\n" +
                "            <option value=\"NF\">Norfolk Island</option>\n" +
                "            <option value=\"MP\">Northern Mariana Islands</option>\n" +
                "            <option value=\"NO\">Norway</option>\n" +
                "            <option value=\"OM\">Oman</option>\n" +
                "            <option value=\"PK\">Pakistan</option>\n" +
                "            <option value=\"PW\">Palau</option>\n" +
                "            <option value=\"PS\">Palestinian Territory, Occupied</option>\n" +
                "            <option value=\"PA\">Panama</option>\n" +
                "            <option value=\"PG\">Papua New Guinea</option>\n" +
                "            <option value=\"PY\">Paraguay</option>\n" +
                "            <option value=\"PE\">Peru</option>\n" +
                "            <option value=\"PH\">Philippines</option>\n" +
                "            <option value=\"PN\">Pitcairn</option>\n" +
                "            <option value=\"PL\">Poland</option>\n" +
                "            <option value=\"PT\">Portugal</option>\n" +
                "            <option value=\"PR\">Puerto Rico</option>\n" +
                "            <option value=\"QA\">Qatar</option>\n" +
                "            <option value=\"RE\">Réunion</option>\n" +
                "            <option value=\"RO\">Romania</option>\n" +
                "            <option value=\"RU\">Russian Federation</option>\n" +
                "            <option value=\"RW\">Rwanda</option>\n" +
                "            <option value=\"BL\">Saint Barthélemy</option>\n" +
                "            <option value=\"SH\">Saint Helena, Ascension and Tristan da Cunha</option>\n" +
                "            <option value=\"KN\">Saint Kitts and Nevis</option>\n" +
                "            <option value=\"LC\">Saint Lucia</option>\n" +
                "            <option value=\"MF\">Saint Martin (French part)</option>\n" +
                "            <option value=\"PM\">Saint Pierre and Miquelon</option>\n" +
                "            <option value=\"VC\">Saint Vincent and the Grenadines</option>\n" +
                "            <option value=\"WS\">Samoa</option>\n" +
                "            <option value=\"SM\">San Marino</option>\n" +
                "            <option value=\"ST\">Sao Tome and Principe</option>\n" +
                "            <option value=\"SA\">Saudi Arabia</option>\n" +
                "            <option value=\"SN\">Senegal</option>\n" +
                "            <option value=\"RS\">Serbia</option>\n" +
                "            <option value=\"SC\">Seychelles</option>\n" +
                "            <option value=\"SL\">Sierra Leone</option>\n" +
                "            <option value=\"SG\">Singapore</option>\n" +
                "            <option value=\"SX\">Sint Maarten (Dutch part)</option>\n" +
                "            <option value=\"SK\">Slovakia</option>\n" +
                "            <option value=\"SI\">Slovenia</option>\n" +
                "            <option value=\"SB\">Solomon Islands</option>\n" +
                "            <option value=\"SO\">Somalia</option>\n" +
                "            <option value=\"ZA\">South Africa</option>\n" +
                "            <option value=\"GS\">South Georgia and the South Sandwich Islands</option>\n" +
                "            <option value=\"SS\">South Sudan</option>\n" +
                "            <option value=\"ES\">Spain</option>\n" +
                "            <option value=\"LK\">Sri Lanka</option>\n" +
                "            <option value=\"SD\">Sudan</option>\n" +
                "            <option value=\"SR\">Suriname</option>\n" +
                "            <option value=\"SJ\">Svalbard and Jan Mayen</option>\n" +
                "            <option value=\"SZ\">Swaziland</option>\n" +
                "            <option value=\"SE\">Sweden</option>\n" +
                "            <option value=\"CH\">Switzerland</option>\n" +
                "            <option value=\"SY\">Syrian Arab Republic</option>\n" +
                "            <option value=\"TW\">Taiwan, Province of China</option>\n" +
                "            <option value=\"TJ\">Tajikistan</option>\n" +
                "            <option value=\"TZ\">Tanzania, United Republic of</option>\n" +
                "            <option value=\"TH\">Thailand</option>\n" +
                "            <option value=\"TL\">Timor-Leste</option>\n" +
                "            <option value=\"TG\">Togo</option>\n" +
                "            <option value=\"TK\">Tokelau</option>\n" +
                "            <option value=\"TO\">Tonga</option>\n" +
                "            <option value=\"TT\">Trinidad and Tobago</option>\n" +
                "            <option value=\"TN\">Tunisia</option>\n" +
                "            <option value=\"TR\">Turkey</option>\n" +
                "            <option value=\"TM\">Turkmenistan</option>\n" +
                "            <option value=\"TC\">Turks and Caicos Islands</option>\n" +
                "            <option value=\"TV\">Tuvalu</option>\n" +
                "            <option value=\"UG\">Uganda</option>\n" +
                "            <option value=\"UA\">Ukraine</option>\n" +
                "            <option value=\"AE\">United Arab Emirates</option>\n" +
                "            <option value=\"GB\">United Kingdom</option>\n" +
                "            <option value=\"US\">United States</option>\n" +
                "            <option value=\"UM\">United States Minor Outlying Islands</option>\n" +
                "            <option value=\"UY\">Uruguay</option>\n" +
                "            <option value=\"UZ\">Uzbekistan</option>\n" +
                "            <option value=\"VU\">Vanuatu</option>\n" +
                "            <option value=\"VE\">Venezuela, Bolivarian Republic of</option>\n" +
                "            <option value=\"VN\">Viet Nam</option>\n" +
                "            <option value=\"VG\">Virgin Islands, British</option>\n" +
                "            <option value=\"VI\">Virgin Islands, U.S.</option>\n" +
                "            <option value=\"WF\">Wallis and Futuna</option>\n" +
                "            <option value=\"EH\">Western Sahara</option>\n" +
                "            <option value=\"YE\">Yemen</option>\n" +
                "            <option value=\"ZM\">Zambia</option>\n" +
                "            <option value=\"ZW\">Zimbabwe</option>\n" +
                "        </select>\n" +
                "    </div>";
        }else if(x == "blooddonor" && data[x] == "0"){
            html += "<p>Voluntary blood donor:</p>\n" +
                "    <div class=\"form-check black\">\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"blooddonor\" id=\"volchoice1\" value=\"1\">\n" +
                "        <label class=\"form-check-label\" for=\"volchoice1\">Yes</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"blooddonor\" id=\"volchoice2\" checked value=\"0\">\n" +
                "        <label class=\"form-check-label\" for=\"volchoice2\">No</label><br>\n" +
                "    </div>";
        }else if(x == "blooddonor"){
            html += "<p>Voluntary blood donor:</p>\n" +
                "    <div class=\"form-check black\">\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"blooddonor\" id=\"volchoice1\" checked value=\"1\">\n" +
                "        <label class=\"form-check-label\" for=\"volchoice1\">Yes</label><br>\n" +
                "        <input class=\"form-check-input\" type=\"radio\" name=\"blooddonor\" id=\"volchoice2\" value=\"0\">\n" +
                "        <label class=\"form-check-label\" for=\"volchoice2\">No</label><br>\n" +
                "    </div>";
        }else if(x!= "user_id"){
            html += "<div class=\"mb-3\">";
            html += "<label for='" + x +"' class=\"form-label\">" + x + "</label>";
            html += "<input type=\"text\" class=\"form-control\" id='"+x+"' name='"+x+"' value='"+data[x]+"' disabled>";
            html += "</div>";
        }
    }
    html += "</form>";
    $("#info-t").append(html);
}

function save(){
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            info = JSON.parse(xhr.responseText);
            $("#content").empty();
            $("#content").append(createDataFromJSON(info));
        }
    }
    let data = "username=";
    for (var x in info){
        if(x == "username"){
            data += info[x]+"&";
            break;
        }
    }
    data += $('#loginForm').serialize();
    console.log(data);
    xhr.open('GET', 'Edit?'+data);
    xhr.setRequestHeader('Content-type','application/x-www-form-urlencoded');
    xhr.send();
    console.log("save");
}

function bmi(){
    const data = null;

    const xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === this.DONE) {
            const resp = JSON.parse(this.responseText);
            console.log(resp);
            let bmi = resp.data.bmi;
            let health = resp.data.health;
            let html = "<p>BMI: "+bmi+"</p>";
            html += "<p>Health: "+health+"</p>";
            $("#info-t").append(html);
        }
    });

    xhr.open("GET", "https://fitness-calculator.p.rapidapi.com/bmi?age="+age+"&weight="+wei+"&height="+hei);
    xhr.setRequestHeader("x-rapidapi-host", "fitness-calculator.p.rapidapi.com");
    xhr.setRequestHeader("x-rapidapi-key", "8f9f4837ebmsh5d225d289db76f7p1915f5jsn95578759396b");

    xhr.send(data);
}

function ideal_weight(){
    const data = null;

    const xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === this.DONE) {
            console.log(this.responseText);
            const resp = JSON.parse(this.responseText);
            let iw = resp.data.Devine;
            let html = "<p>Ideal Weight: "+iw+"</p>";
            $("#info-t").append(html);
        }
    });

    xhr.open("GET", "https://fitness-calculator.p.rapidapi.com/idealweight?gender="+gen+"&height="+hei);
    xhr.setRequestHeader("x-rapidapi-host", "fitness-calculator.p.rapidapi.com");
    xhr.setRequestHeader("x-rapidapi-key", "8f9f4837ebmsh5d225d289db76f7p1915f5jsn95578759396b");

    xhr.send(data);
}